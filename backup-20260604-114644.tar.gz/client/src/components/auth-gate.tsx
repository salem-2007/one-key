import { useEffect, useState, type ReactNode } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { apiFetch, setToken, UNAUTHORIZED_EVENT } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useI18n } from '@/lib/i18n'
import { Zap, ArrowLeft, Copy, Check, Eye, EyeOff } from 'lucide-react'

interface AuthStatus {
  needsSetup: boolean
  authenticated: boolean
  email: string | null
}

function Centered({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm">{children}</div>
    </div>
  )
}

type AuthMode = 'setup' | 'login' | 'forgot' | 'reset'

function AuthForm({ mode: initialMode, onAuthed }: { mode: 'setup' | 'login'; onAuthed: () => void }) {
  const [mode, setMode] = useState<AuthMode>(initialMode)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [resetToken, setResetToken] = useState('')
  const [generatedToken, setGeneratedToken] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [busy, setBusy] = useState(false)
  const [copied, setCopied] = useState(false)
  const { t, lang, setLang } = useI18n()

  const isSetup = mode === 'setup'

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError('')
    setSuccess('')
    try {
      if (mode === 'forgot') {
        const res = await apiFetch<{ success: boolean; resetToken?: string }>('/api/auth/forgot-password', {
          method: 'POST',
          body: JSON.stringify({ email }),
        })
        if (res.resetToken) {
          setGeneratedToken(res.resetToken)
          setSuccess(t('auth.forgot.success'))
        }
      } else if (mode === 'reset') {
        await apiFetch('/api/auth/reset-password', {
          method: 'POST',
          body: JSON.stringify({ token: resetToken, password }),
        })
        setSuccess(t('auth.reset.success'))
        setTimeout(() => {
          setMode('login')
          setSuccess('')
          setPassword('')
          setResetToken('')
        }, 2000)
      } else {
        const res = await apiFetch<{ token: string }>(isSetup ? '/api/auth/setup' : '/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        })
        setToken(res.token)
        onAuthed()
      }
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  async function copyToken() {
    if (generatedToken) {
      await navigator.clipboard.writeText(generatedToken)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  function resetForm() {
    setError('')
    setSuccess('')
    setPassword('')
    setResetToken('')
    setGeneratedToken('')
  }

  return (
    <Centered>
      {/* Logo */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center justify-center size-12 rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-blue-500/25 mb-4">
          <Zap size={24} className="text-white" fill="currentColor" />
        </div>
        <h1 className="text-xl font-bold tracking-tight">ONE KEY</h1>
        <p className="text-xs text-muted-foreground mt-1">
          {mode === 'forgot' ? t('auth.forgot.desc') : mode === 'reset' ? t('auth.reset.desc') : isSetup ? t('auth.create.desc') : t('auth.signin.desc')}
        </p>
      </div>

      {/* Form Card */}
      <div className="rounded-xl border bg-card p-6 shadow-sm">
        <form onSubmit={submit} className="space-y-4">
          {mode === 'forgot' ? (
            /* Forgot Password Form */
            <>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium" htmlFor="auth-email">{t('auth.email')}</Label>
                <Input
                  id="auth-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="h-9"
                />
              </div>
              {generatedToken && (
                <div className="space-y-2">
                  <Label className="text-xs font-medium">{t('auth.forgot.token')}</Label>
                  <div className="flex gap-2">
                    <Input
                      value={generatedToken}
                      readOnly
                      className="h-9 font-mono text-xs"
                    />
                    <Button type="button" variant="outline" size="sm" onClick={copyToken} className="shrink-0">
                      {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                    </Button>
                  </div>
                  <p className="text-xs text-amber-600 bg-amber-50 dark:bg-amber-950/30 dark:text-amber-400 rounded-lg px-3 py-2">
                    ⚠️ {t('auth.forgot.success')}
                  </p>
                </div>
              )}
            </>
          ) : mode === 'reset' ? (
            /* Reset Password Form */
            <>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium" htmlFor="reset-token">{t('auth.reset.token')}</Label>
                <Input
                  id="reset-token"
                  type="text"
                  value={resetToken}
                  onChange={e => setResetToken(e.target.value)}
                  placeholder="paste your reset token"
                  className="h-9 font-mono text-xs"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium" htmlFor="reset-password">{t('auth.reset.newPassword')}</Label>
                <div className="relative">
                  <Input
                    id="reset-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="at least 8 characters"
                    className="h-9 pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* Login / Setup Form */
            <>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium" htmlFor="auth-email">{t('auth.email')}</Label>
                <Input
                  id="auth-email"
                  type="email"
                  autoComplete="username"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium" htmlFor="auth-password">{t('auth.password')}</Label>
                <div className="relative">
                  <Input
                    id="auth-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete={isSetup ? 'new-password' : 'current-password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={isSetup ? 'at least 8 characters' : 'your password'}
                    className="h-9 pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
              {mode === 'login' && (
                <div className="text-right">
                  <button
                    type="button"
                    onClick={() => { setMode('forgot'); resetForm(); }}
                    className="text-xs text-muted-foreground hover:text-primary transition-colors"
                  >
                    {t('auth.forgot')}
                  </button>
                </div>
              )}
            </>
          )}

          {error && (
            <div className="rounded-lg bg-destructive/10 border border-destructive/20 px-3 py-2">
              <p className="text-destructive text-xs">{error}</p>
            </div>
          )}
          {success && (
            <div className="rounded-lg bg-green-500/10 border border-green-500/20 px-3 py-2">
              <p className="text-green-600 dark:text-green-400 text-xs">{success}</p>
            </div>
          )}

          <Button type="submit" className="w-full h-9" disabled={busy || (mode === 'login' && (!email || !password)) || (mode === 'forgot' && !email) || (mode === 'reset' && (!resetToken || !password))}>
            {busy ? '...' : mode === 'forgot' ? t('auth.forgot.btn') : mode === 'reset' ? t('auth.reset.btn') : isSetup ? t('auth.create.btn') : t('auth.signin')}
          </Button>
        </form>

        {/* Back to login link */}
        {(mode === 'forgot' || mode === 'reset') && (
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => { setMode('login'); resetForm(); }}
              className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft size={12} />
              {mode === 'forgot' ? t('auth.forgot.back') : t('auth.reset.back')}
            </button>
          </div>
        )}

        {/* Switch between login and reset */}
        {mode === 'login' && (
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => { setMode('reset'); resetForm(); }}
              className="text-xs text-muted-foreground hover:text-primary transition-colors"
            >
              {t('auth.reset')}
            </button>
          </div>
        )}
      </div>

      {/* Language Toggle */}
      <div className="mt-4 flex justify-center">
        <Button variant="ghost" size="sm" onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')} className="text-xs text-muted-foreground">
          {lang === 'zh' ? 'Switch to English' : '切换到中文'}
        </Button>
      </div>
    </Centered>
  )
}

export function AuthGate({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient()
  const { data, isLoading, isError, refetch } = useQuery<AuthStatus>({
    queryKey: ['auth-status'],
    queryFn: () => apiFetch('/api/auth/status'),
    retry: false,
  })

  useEffect(() => {
    const handler = () => { refetch() }
    window.addEventListener(UNAUTHORIZED_EVENT, handler)
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, handler)
  }, [refetch])

  function onAuthed() {
    queryClient.invalidateQueries()
    refetch()
  }

  if (isLoading) return (
    <Centered>
      <div className="flex flex-col items-center gap-3">
        <div className="size-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        <p className="text-sm text-muted-foreground">Loading…</p>
      </div>
    </Centered>
  )
  if (isError || !data) {
    return (
      <Centered>
        <div className="rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive text-center">
          Can't reach the server. Make sure the backend is running.
        </div>
      </Centered>
    )
  }

  if (data.needsSetup) return <AuthForm mode="setup" onAuthed={onAuthed} />
  if (!data.authenticated) return <AuthForm mode="login" onAuthed={onAuthed} />

  return <>{children}</>
}
