import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate, NavLink, useLocation } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { AuthGate } from '@/components/auth-gate'
import { logout } from '@/lib/api'
import { I18nProvider, useI18n } from '@/lib/i18n'
import {
  MessageSquare, Key, Shield, BarChart3, Server, ChevronLeft, ChevronRight, Languages, Zap,
} from 'lucide-react'
import KeysPage from '@/pages/KeysPage'
import PlaygroundPage from '@/pages/PlaygroundPage'
import FallbackPage from '@/pages/FallbackPage'
import AnalyticsPage from '@/pages/AnalyticsPage'
import ProvidersPage from '@/pages/ProvidersPage'

const queryClient = new QueryClient()

function DarkModeToggle() {
  const [dark, setDark] = useState(() =>
    typeof window !== 'undefined' && document.documentElement.classList.contains('dark')
  )

  useEffect(() => {
    const stored = localStorage.getItem('theme')
    if (stored === 'dark' || (!stored && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark')
      setDark(true)
    }
  }, [])

  function toggle() {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
    localStorage.setItem('theme', next ? 'dark' : 'light')
  }

  return (
    <Button variant="ghost" size="sm" onClick={toggle} aria-label="Toggle theme" className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground">
      {dark ? (
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
      )}
    </Button>
  )
}

function LangToggle() {
  const { lang, setLang } = useI18n()
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
      aria-label="Toggle language"
      className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
    >
      <Languages size={15} />
    </Button>
  )
}

function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const location = useLocation()
  const { t } = useI18n()

  const navItems = [
    { key: 'analytics', label: t('nav.analytics'), icon: <BarChart3 size={17} strokeWidth={1.5} />, path: '/analytics' },
    { key: 'providers', label: t('nav.providers'), icon: <Server size={17} strokeWidth={1.5} />, path: '/providers' },
    { key: 'fallback', label: t('nav.fallback'), icon: <Shield size={17} strokeWidth={1.5} />, path: '/fallback' },
    { key: 'keys', label: t('nav.keys'), icon: <Key size={17} strokeWidth={1.5} />, path: '/keys' },
    { key: 'playground', label: t('nav.playground'), icon: <MessageSquare size={17} strokeWidth={1.5} />, path: '/playground' },
  ]

  return (
    <aside className={`fixed inset-y-0 left-0 z-40 flex flex-col border-r border-border/40 bg-card/70 backdrop-blur-xl transition-all duration-300 ease-in-out ${collapsed ? 'w-[64px]' : 'w-[220px]'}`}>
      {/* Logo */}
      <div className="flex items-center h-14 px-4 border-b border-border/40">
        {!collapsed ? (
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center size-7 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 shadow-sm">
              <Zap size={14} className="text-white" fill="currentColor" />
            </div>
            <span className="font-semibold text-[13px] tracking-tight">ONE KEY</span>
          </div>
        ) : (
          <div className="flex items-center justify-center size-7 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 shadow-sm mx-auto">
            <Zap size={14} className="text-white" fill="currentColor" />
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2">
        {!collapsed && (
          <p className="px-3 mb-2 text-[10px] font-medium uppercase tracking-[0.08em] text-muted-foreground/50">
            {t('nav.navigation')}
          </p>
        )}
        {navItems.map(item => {
          const active = location.pathname === item.path
          return (
            <NavLink
              key={item.key}
              to={item.path}
              title={collapsed ? item.label : undefined}
              className={`group flex items-center gap-3 px-3 py-[7px] rounded-lg text-[13px] mb-[2px] transition-all duration-200 relative ${
                active
                  ? 'bg-primary/[0.08] text-primary font-medium'
                  : 'text-muted-foreground hover:bg-muted/40 hover:text-foreground'
              } ${collapsed ? 'justify-center' : ''}`}
            >
              {active && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-4 rounded-r-full bg-primary transition-all duration-200" />
              )}
              <span className={`transition-colors duration-200 ${active ? 'text-primary' : 'text-muted-foreground/70 group-hover:text-foreground'}`}>
                {item.icon}
              </span>
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-border/40 px-2 py-2 space-y-1">
        {!collapsed && (
          <div className="flex items-center justify-center gap-1 px-1">
            <LangToggle />
            <DarkModeToggle />
          </div>
        )}
        <div className="flex items-center justify-center gap-1">
          <button
            onClick={onToggle}
            className="flex items-center justify-center p-2 rounded-lg hover:bg-muted/40 transition-colors duration-200 text-muted-foreground/60 hover:text-foreground"
          >
            {collapsed ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
          </button>
          {!collapsed && (
            <Button variant="ghost" size="sm" onClick={() => logout()} className="text-xs text-muted-foreground/60 hover:text-foreground h-8">
              {t('nav.signout')}
            </Button>
          )}
        </div>
      </div>
    </aside>
  )
}

function App() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <BrowserRouter basename={import.meta.env.BASE_URL}>
          <AuthGate>
            <div className="flex min-h-screen bg-background relative">
              {/* 背景装饰 - 让毛玻璃效果可见 */}
              <div className="fixed inset-0 pointer-events-none z-0">
                <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-500/[0.03] rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-1/4 w-[500px] h-[500px] bg-violet-500/[0.03] rounded-full blur-[100px]" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-emerald-500/[0.02] rounded-full blur-[120px]" />
                {/* 网格背景 */}
                <div className="absolute inset-0" style={{
                  backgroundImage: `radial-gradient(circle at 1px 1px, oklch(0 0 0 / 0.03) 1px, transparent 0)`,
                  backgroundSize: '24px 24px'
                }} />
              </div>

              <Sidebar collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} />
              <main
                className="flex-1 px-6 py-6 relative z-10 transition-all duration-300 ease-in-out"
                style={{ marginLeft: collapsed ? '64px' : '220px' }}
              >
                <Routes>
                  <Route path="/" element={<Navigate to="/analytics" replace />} />
                  <Route path="/playground" element={<PlaygroundPage />} />
                  <Route path="/keys" element={<KeysPage />} />
                  <Route path="/fallback" element={<FallbackPage />} />
                  <Route path="/providers" element={<ProvidersPage />} />
                  <Route path="/analytics" element={<AnalyticsPage />} />
                  <Route path="/test" element={<Navigate to="/playground" replace />} />
                  <Route path="/health" element={<Navigate to="/keys" replace />} />
                </Routes>
              </main>
            </div>
          </AuthGate>
        </BrowserRouter>
      </I18nProvider>
    </QueryClientProvider>
  )
}

export default App
